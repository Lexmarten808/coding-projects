#Importar la libreria para trabajar la interfaz gráfica
from tkinter import *
from tkinter import simpledialog
from tkinter import messagebox

def salir():
	raiz.destroy()



def principal():
        pass
        

#Interfaz Gráfica
raiz = Tk()
raiz.title("Programa")
raiz.resizable(0,0)
raiz.geometry("550x350")

#Contenedor 1
ventana1 = Frame(raiz)
ventana1.config(bd=5,relief="sunken")
ventana1.pack(padx =10, pady=10)

bCalcularPago = Button(ventana1, text="Procesar", command=principal)
bCalcularPago.grid(row=3, column=0,padx=10, pady=10)

bSalir = Button(ventana1, text="Salir", width=10, command=salir)
bSalir.grid(row=3, column=1)

# Area de texto para mostrar el reporte.
ctReporte = Text(raiz, height=13, width=50)
ctReporte.pack()

raiz.mainloop()

