'''
programa que solicita la
temperatura de cada uno de los sietes días de la semana y
luego muestra la temperatura promedio, la temperatura
más alta, y la más baja
'''
semana = ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado']

def leerDatos(arreglo):
    for i in range(len(arreglo)):
        arreglo[i] = float(input("Temperatura " + semana[i] + ": "))

def mostrarDatos(arreglo):
    for i in range(len(arreglo)):
        print(semana[i] + " : " + str(arreglo[i]))

def calcPromedio(arreglo):
    suma = 0
    n = len(arreglo)

    for x in arreglo:
        suma += x

    return suma / n

def calcMaximo(arreglo):
    maximo = arreglo[0]

    for i in range(1, len(arreglo)):
        if arreglo[i] > maximo:
            maximo = arreglo[i]

    return maximo

def calMinimo(arreglo):
    menor = arreglo[0]

    for i in range(1, len(arreglo)):
        if arreglo[i] < menor:
            menor = arreglo[i]
            
    return menor

def calcularModa(arreglo):
    contadores = [0]*len(arreglo)

    for x in range(len(arreglo)):  #  x = arreglo[j]
        for i in range(len(arreglo)):
            if arreglo[x] == arreglo[i]:
                contadores[x] += 1

    mayor = contadores[0]
    pos_mayor = 0
    for i in range(1, len(contadores)):
        if contadores[i] > mayor:
            mayor = contadores[i]
            pos_mayor = i

    return arreglo[pos_mayor]

def main():
    # 7 temperaturas: una por cada dia de la semana
    temperaturas = [None]*7  
    opcion = 1

    while opcion != 9:
        print("Menu: ")
        print("1: leer Datos")
        print("2: Mostrar Datos")
        print("3: Mostrar Promedio")
        print("4: Mostrar Maximo")
        print("5: Mostrar Minimo")
        print("6: Mostrar Moda")
        print("9: salir")
        opcion = int(input("opcion: "))

        if opcion == 1:
            leerDatos(temperaturas)
        elif opcion == 2:
            mostrarDatos(temperaturas)
        elif opcion == 3:
            p = calcPromedio(temperaturas)
            print("Promedio: ", p)
        elif opcion == 4:
            m = calcMaximo(temperaturas)
            print("Maximo: ", m)
        elif opcion == 5:
            m = calMinimo(temperaturas)
            print("Minimo: ", m)
        elif opcion == 6:
            m = calcularModa(temperaturas)
            print("Moda: ", m)
            
main()
