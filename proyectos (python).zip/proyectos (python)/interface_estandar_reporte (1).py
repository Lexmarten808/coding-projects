#Importar la libreria para trabajar la interfaz gráfica
from tkinter import *
from tkinter import simpledialog # entradas
from tkinter import messagebox   # salidas, mensajes

nombres = []
cantidades = []
precios = []

def salir():
        raiz.destroy()

def llenar():
        seguir = True
        while seguir:
              nombres.append(simpledialog.askstring("Nombre","Nombre: "))
              cantidades.append(simpledialog.askinteger("Cantidad", "Cantidad: "))
              precios.append(simpledialog.askfloat("Precio", "Precio: "))

              seguir = messagebox.askyesno("Seguir", "Desea seguir?") 

        mostrar()

def mostrar():
        reporte = "Nombre\t\tCantidad\t\tPrecio\t\tSubtotal\n"
        for i in range(len(nombres)):
                subtotal = cantidades[i]*precios[i]
                reporte += nombres[i]+"\t\t"+str(cantidades[i])+"\t\t"+str(precios[i])+"\t\t"+str(subtotal)+"\n"

        ctReporte.insert(END, reporte)

def ordernarNombre():
        for i in range(len(nombres)):
                for j in range(len(nombres)-i-1):
                        if nombres[j] > nombres[j+1]:
                                temp = nombres[j]
                                nombres[j] = nombres[j+1]
                                nombres[j+1] = temp
                                
                                temp = cantidades[j]
                                cantidades[j] = cantidades[j+1]
                                cantidades[j+1] = temp
                                
                                temp = precios[j]
                                precios[j] = precios[j+1]
                                precios[j+1] = temp

        mostrar()

def ordernarCantidad():
        for i in range(len(nombres)):
                for j in range(len(nombres)-i-1):
                        if cantidades[j] > cantidades[j+1]:
                                temp = nombres[j]
                                nombres[j] = nombres[j+1]
                                nombres[j+1] = temp
                                
                                temp = cantidades[j]
                                cantidades[j] = cantidades[j+1]
                                cantidades[j+1] = temp
                                
                                temp = precios[j]
                                precios[j] = precios[j+1]
                                precios[j+1] = temp

        mostrar()

def mostrar_autor():
    messagebox.showinfo(message="BRANDON LASPRILLA", title="Autor")

def ordernarPrecios():
        for i in range(len(nombres)):
                for j in range(len(nombres)-i-1):
                        if precios[j] > precios[j+1]:
                                temp = nombres[j]
                                nombres[j] = nombres[j+1]
                                nombres[j+1] = temp
                                
                                temp = cantidades[j]
                                cantidades[j] = cantidades[j+1]
                                cantidades[j+1] = temp
                                
                                temp = precios[j]
                                precios[j] = precios[j+1]
                                precios[j+1] = temp

        mostrar()

def principal():
        pass
        
#Interfaz Gráfica
raiz = Tk()
raiz.title("Programa")
raiz.resizable(0,0)
raiz.geometry("600x400")

#Contenedor 1
ventana1 = Frame(raiz)
ventana1.config(bd=5,relief="sunken")
ventana1.pack(padx =10, pady=10)

bCalcularPago = Button(ventana1, text="Leer Datos", command=llenar)
bCalcularPago.grid(row=0, column=0,padx=10, pady=10)

bSalir = Button(ventana1, text="Salir", width=10, command=salir)
bSalir.grid(row=0, column=1)

btnOrdernarNombre = Button(ventana1, text="Ordenar por Nombre", command=ordernarNombre)
btnOrdernarNombre.grid(row=1, column=0,padx=10, pady=10)

btnOrdenarCantidad = Button(ventana1, text="Ordenar Por Cantidad", command=ordernarCantidad)
btnOrdenarCantidad.grid(row=1, column=1,padx=10, pady=10)

btnOrdenarPrecio = Button(ventana1, text="Ordenar por Precio", command=ordernarPrecios)
btnOrdenarPrecio.grid(row=1, column=2,padx=10, pady=10)

# Area de texto para mostrar el reporte.
ctReporte = Text(raiz, height=13, width=60)
ctReporte.pack()

botonAceptar = Button(raiz, text="Mostrar Autor", command=mostrar_autor )
botonAceptar.pack(side="right")

raiz.mainloop()
