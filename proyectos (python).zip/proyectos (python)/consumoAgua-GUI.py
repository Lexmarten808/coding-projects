#Importar la libreria para trabajar la interfaz gráfica
from tkinter import *

#Subproceso salir
def salir():
	raiz.destroy()


#Interfaz Gráfica
raiz = Tk()
raiz.title("Calcular valor de la factura de agua")
raiz.resizable(0,0)

#Contenedor de los controles de usuario
ventana = Frame(raiz, bd=5, relief="sunken")
ventana.pack(padx=10, pady=10)

nombreLabel = Label(ventana, text="Nombre:")
nombreLabel.grid(row = 0, column = 0, sticky = "w", padx = 10, pady=5)
ctNombre = Entry(ventana)
ctNombre.grid(row=0, column = 1, padx = 10, pady=5)

numeroPredioLabel = Label(ventana, text="Número de predio:")
numeroPredioLabel.grid(row = 0, column = 2, sticky = "w", padx = 10, pady=5)
ctNumeroPredio = Entry(ventana)
ctNumeroPredio.grid(row=0, column = 3, padx = 10, pady=5)

consumoLabel = Label(ventana, text="Consumo en metros cúbicos:")
consumoLabel.grid(row = 1, column = 0, sticky = "w", padx = 10, pady=5)
ctConsumo = Entry(ventana)
ctConsumo.grid(row=1, column = 1, padx = 10, pady=5)

estratoLabel = Label(ventana, text="Estrato:")
estratoLabel.grid(row = 1, column = 2, sticky = "w", padx = 10, pady=5)
ctEstrato = Entry(ventana)
ctEstrato.grid(row=1, column = 3, padx = 10, pady=5)

pagoLabel = Label(ventana, text="Valor a pagar: ")
pagoLabel.grid(row = 2, column = 0, sticky = "w", padx = 10, pady=5)
varPago = StringVar()
ctPago = Entry(ventana, textvariable = varPago, state="readonly")
ctPago.grid(row=2, column = 1, padx = 10, pady=5)

bCalcularPago = Button(ventana, text="Calcular Pago")
bCalcularPago.grid(row=3, column=1,padx=10, pady=10)
bSalir = Button(ventana, text="Salir", width=10, command= salir)
bSalir.grid(row=3, column=2)

raiz.mainloop()



























