from tkinter import *

def salir():
    raiz.destroy()

#Interfaz gráfica
raiz = Tk()
raiz.title("Mayor y diferencia")
raiz.resizable(0,0)

#Contenedor datos
contenedorDatos = LabelFrame(raiz, text="Datos")
contenedorDatos.pack(padx =10, pady=10)
n1Label = Label(contenedorDatos, text="Número 1: ").grid(row=0, column=0, stick='w')
n1Ct = Entry(contenedorDatos)
n1Ct.grid(row=0,column=1, padx=5, pady=5)
n2Label = Label(contenedorDatos, text="Número 2: ").grid(row=1, column=0, stick='w')
n2Ct = Entry(contenedorDatos)
n2Ct.grid(row=1,column=1, padx=5, pady=5)
mayorLabel = Label(contenedorDatos, text="Mayor: ").grid(row=2, column=0, stick='w')
varMayor = StringVar();
mayorCt = Entry(contenedorDatos, textvariable= varMayor, state = "readonly")
mayorCt.grid(row=2,column=1, padx=5, pady=5)
diferenciaLabel = Label(contenedorDatos, text="Diferencia: ").grid(row=3, column=0, stick='w')
varDiferencia = StringVar()
diferenciaCt = Entry(contenedorDatos,textvariable= varDiferencia, state = "readonly")
diferenciaCt.grid(row=3,column=1, padx=5, pady=5)
 
#Contenedor botones
contenedorBotones = LabelFrame(raiz, text="")
contenedorBotones.pack(padx =10, pady=10)
iniciarB = Button(contenedorBotones, text="Iniciar", width=10).grid(row=0, column=0, padx=5, pady=5)
salirB = Button(contenedorBotones, text="Salir", width=10, command= salir).grid(row=0, column=1, padx=5, pady=5)

raiz.mainloop()
