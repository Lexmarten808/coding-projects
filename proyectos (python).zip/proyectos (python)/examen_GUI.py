#Importar la libreria para trabajar la interfaz gráfica
from tkinter import *
from tkinter import simpledialog
from tkinter import messagebox

estudiantes = []   
def salir():
        raiz.destroy()

def mostrar_autor():
    messagebox.showinfo(message="BRANDON LASPRILLA", title="Autor")

def agregar_estudiantes():
         
    estudiante = simpledialog.askstring("NOMBRE", "Nombre del estudiante:", parent=raiz)
    nota = simpledialog.askfloat("NOTA", f"Nota de {estudiante}:", parent=raiz) 
    estudiantes.append((estudiante, nota))
    actualizar_reporte(estudiantes)   

def actualizar_reporte(estudiantes):
    ctReporte.delete('1.0', END)
    for estudiante, nota in estudiantes:
        ctReporte.insert(END, f"{estudiante}: {nota}\n")
    calcular_promedio(estudiantes)

def calcular_promedio(estudiantes):
    if estudiantes:
        promedio = sum(nota for _, nota in estudiantes) / len(estudiantes)
        varPromedio.set(f"{promedio:.2f}")
        mostrar_estudiantes_mayores(estudiantes, promedio)    

def mostrar_estudiantes_mayores(estudiantes, promedio):
    ctReporteMayores.delete('1.0', END)
    for estudiante, nota in estudiantes:
        if nota >= promedio:
            ctReporteMayores.insert(END, f"{estudiante}: {nota}\n")

#Interfaz Gráfica
raiz = Tk()
raiz.title("Examen final - Fundamentos de Programación Imperativa")
raiz.resizable(0,0)
raiz.geometry("650x500")

#Contenedor 1
ventana1 = Frame(raiz)
ventana1.config(bd=5,relief="sunken")
ventana1.pack(padx =10, pady=10)

btnIniciar = Button(ventana1, text="Iniciar proceso",command=agregar_estudiantes )
btnIniciar.grid(row=0, column=0,padx=10, pady=10)

bAutor = Button(ventana1, text="Autor", width=10,command=mostrar_autor)
bAutor.grid(row=0, column=1)

bSalir = Button(ventana1, text="Salir", width=10, command= salir)
bSalir.grid(row=0, column=2)


# Area de texto para mostrar el reporte.
mensajeLabel = Label(raiz, text="Listado completo de estudiantes")
mensajeLabel.pack()
ctReporte = Text(raiz, height = 8, width = 52)
#ctReporte.insert(END, 'Correct')
ctReporte.pack()

contenedor1 = LabelFrame(raiz, text="Salida", bd = 3)
contenedor1.pack(padx = 5, pady = 5)


promedioLabel = Label(contenedor1, text="Promedio: ").grid(row=0, column=0, sticky="w", padx=5, pady=5)
varPromedio = StringVar()
promedioTb = Entry(contenedor1, textvariable=varPromedio, state="readonly")
promedioTb.grid(row=0, column=1, padx=5, pady=5, sticky="w")

mensaje2Label = Label(raiz, text="Listado de estudiantes con nota mayor al promedio: ")
mensaje2Label.pack()
ctReporteMayores = Text(raiz, height = 8, width = 52)
#ctReporte.insert(END, 'Correct')
ctReporteMayores.pack()



raiz.mainloop()

