from tkinter import *
from tkinter import messagebox
from tkinter import simpledialog
import math

def calcularArea(radio):
    return math.pi * radio * radio

def mostrar_autor():
    messagebox.showinfo(message="John Vargas", title="Autor")

def procesar():
    radio = float(inRadio.get())  # leyendo la entrada
    area = calcularArea(radio)
    varRadio.set(str(area))  ## mostrar la salida

# Diseño de la GUI
raiz = Tk()

# personalizacion de la ventana
raiz.title("Ejemplo GUI v1.0") # titulo
raiz.geometry("300x200")
raiz.config(bg='#C0A375') # RRGGBB   FFFFFF

# Zona para los datos de entrada
marcoIn = LabelFrame(raiz, text="Datos de entrada")
marcoIn.config(bg="#EBC597", width=250, height=100)
marcoIn.pack(pady=5)

etiqueta = Label(marcoIn, text="Ingrese el radio: ", bg="#EBC597")
etiqueta.pack(pady=5, side="left")

inRadio = Entry(marcoIn)
inRadio.pack(pady=5, side="right")

# Zona para los datos de salida
marcoOut = LabelFrame(raiz, text="Datos de salida")
marcoOut.config(bg="#EBC597", width=250, height=100)
marcoOut.pack(pady=5)

etiquetaOut = Label(marcoOut, text="Area: ", bg="#EBC597")
etiquetaOut.pack(pady=5, side="left")

varRadio = StringVar() # objeto para escribir el dato de salida
outRadio = Entry(marcoOut, textvariable=varRadio, bg="#EBC597", width=28, state='readonly')
outRadio.pack(pady=5, side="right")

# Zona para los botones que ejecutan los algoritmos
botonCalcular = Button(raiz, text="Calcular Area", command=procesar )
botonCalcular.pack(side="left")

botonAceptar = Button(raiz, text="Mostrar Autor", command=mostrar_autor )
botonAceptar.pack(side="right")

raiz.mainloop()
