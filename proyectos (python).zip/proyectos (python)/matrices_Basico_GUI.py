#Importar la libreria para trabajar la interfaz gráfica
from tkinter import *
from tkinter import simpledialog
from tkinter import messagebox
import tkinter.font as tkFont

# Estructura de datos (arreglo)
#datos = [None]*100  # separo espacio (100) en memoria para guardar los datos
datos = []
datos2 = []

def salir():
	raiz.destroy()

def leerDatos():
    entrada = ctEntrada.get("1.0","end")
    filas = entrada.strip().split("\n")
    numFilas = len(filas)
    
    for fila in filas:
        if fila.strip() != "":
            datos.append( fila.strip().split(" "))
                    
    mostrarDatos()
                  
def mostrarDatos():
    reporteDatos = ""
    n = len(datos)

    for i in range(n):  # i = 0,1,2,...,n-1
        for j in range(len(datos[i])):
            reporteDatos += str(datos[i][j]) + " | "
        reporteDatos += "\n"

    reporteDatos = "Datos: \n" + reporteDatos
    ctSalida.insert(END, reporteDatos)


def traspuesta():
    global datos
    matriz = []
    for i in range(len(datos)):
        matriz.append([None]*len(datos[i]))
        for j in range(len(datos[i])):
            matriz[i][j] = datos[j][i]

    datos = matriz

    mostrarDatos()

def traspuesta2(datos):
    matriz = []
    for i in range(len(datos)):
        matriz.append([None]*len(datos[i]))
        for j in range(len(datos[i])):
            matriz[i][j] = datos[j][i]

    return matriz

def diagonal():
    reporte = ""
    n = len(datos)

    for i in range(n):
        reporte += datos[i][i] + ","

    ctSalida.insert(END, "Diagonal: " + reporte)

def productoEscalar():
    escalar = simpledialog.askinteger("Escalar", "Escalar: ")
    matriz = [None]*len(datos)  ## Igual cantidad de filas que datos

    for i in range(len(datos)):
        matriz[i] = [None]*len(datos[i]) ## Igual cantidad de columnas a la fila i
        for j in range(len(datos[i])):
            matriz[i][j] = int(datos[i][j]) * escalar

    reporte = ""
    for fila in matriz:
        reporte += "\t".join([str(x) for x in fila]) + "\n"
    
    ctSalida.insert(END, reporte)

# Retorna el producto escalar (punto) entre dos vectores
def productoPunto(vector1, vector2):
    escalar = 0
    for i in range(len(vector1)):   
        escalar += int(vector1[i])*int(vector2[i])
              
    return escalar

def mainPunto():
    entrada = ctEntrada.get("1.0","end")
    vector1 = entrada.strip().split(" ")
    
    entrada2 = ctEntrada2.get("1.0","end")
    vector2 = entrada2.strip().split(" ")

    escalar = productoPunto(vector1, vector2)

    ctSalida.insert(END, "Producto punto: " + str(escalar))

def productoMatrices(matriz1, matriz2):
    producto = [None]*len(matriz1)
    trans = traspuesta2(matriz2)

    for i in range(len(matriz1)):
        producto[i] = [None]*len(matriz1[i])
        for j in range(len(matriz2[i])):
            producto[i][j] = productoPunto(matriz1[i], matriz2[j])            

    return producto

def mainMultiMatrices():    
    global datos
    entrada = ctEntrada.get("1.0","end")
    filas = entrada.strip().split("\n")
    numFilas = len(filas)
    matriz1 = []
    
    for fila in filas:
        if fila.strip() != "":
            matriz1.append( fila.strip().split(" "))

            
    entrada = ctEntrada2.get("1.0","end")
    filas = entrada.strip().split("\n")
    numFilas = len(filas)
    matriz2 = []
    
    for fila in filas:
        if fila.strip() != "":
            matriz2.append( fila.strip().split(" "))

    datos = productoMatrices(matriz1, matriz2)
    mostrarDatos()


   
#Interfaz Gráfica
raiz = Tk()
raiz.title("Interfaz Basica GUI")
raiz.resizable(0,0)
raiz.geometry("650x650")

#Contenedor 1
ventana1 = Frame(raiz)
ventana1.config(bd=5,relief="sunken")
ventana1.pack(padx =10, pady=10)

btnLeer = Button(ventana1, text="Leer datos", command= leerDatos)
btnLeer.grid(row=0, column=0,padx=10, pady=10)

btnMostrar = Button(ventana1, text="Traspuesta", command= traspuesta)
btnMostrar.grid(row=0, column=1,padx=10, pady=10)

btnMostrar = Button(ventana1, text="Diagonal", command= diagonal)
btnMostrar.grid(row=1, column=0,padx=10, pady=10)

bSalir = Button(ventana1, text="Salir", width=10, command= salir)
bSalir.grid(row=1, column=1)

btnProductoEscalar = Button(ventana1, text="Producto Escalar", command=productoEscalar)
btnProductoEscalar.grid(row=2, column=0)

btnEjer13 = Button(ventana1, text="Producto Punto", command=mainPunto)
btnEjer13.grid(row=2, column=1)

btnMulMatrices = Button(ventana1, text="Producto de Matrices", command=mainMultiMatrices)
btnMulMatrices.grid(row=2, column=2)

#Contenedor 2
ventana = LabelFrame(raiz, text="Entradas")
ventana.config(bd=5,relief="sunken")
ventana.pack(padx =10, pady=10)

# Matriz de entrada
fontObj = tkFont.Font(size=14)
txtEntrada = Label(ventana, text="1: ")
txtEntrada.grid(row=0, column=0)
ctEntrada = Text(ventana, height = 5, width = 20, font=fontObj)
#ctReporte.insert(END, 'Correct')
ctEntrada.grid(row=1, column=0)

txtEntrada2 = Label(ventana, text="2: ")
txtEntrada2.grid(row=0, column=1)
ctEntrada2 = Text(ventana, height = 5, width = 20, font=fontObj)
ctEntrada2.grid(row=1, column=1)

# MAtriz de salida
txtSalida = Label(raiz, text="Salida: ")
txtSalida.pack()
ctSalida = Text(raiz, height = 10, width = 40, font=fontObj)
#ctReporte.insert(END, 'Correct')
ctSalida.pack()

raiz.mainloop()









