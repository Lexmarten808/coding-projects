def esPrimoFor(n):
    esPrimo = True
    for x in range(2, n):
        if n % x == 0:
            esPrimo = False
            break
    return esPrimo

def esPrimoWhile(n):
    esPrimo = True
    x = 2
    while esPrimo:
        if n % x == 0:
            esPrimo = False
        x += 1
    return esPrimo

def esPrimoRecursivo(x, n):
    if x < n:
        if n % x == 0:
            return False
        else:
            return esPrimoRecursivo(x+1,n)
    return True

def main():
    seguir = 's'
    while seguir == 's':
        n = int(input("Ingrese n:"))
        if esPrimoRecursivo(2, n):
            print("Es primo")
        else:
            print("No es primo")
    seguir = input("Desea seguir?(s/n)")
main()