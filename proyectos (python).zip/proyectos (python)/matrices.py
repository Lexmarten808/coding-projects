'''
programa maneja matrices
'''
matriz = []

def leerDatos():
    global matriz
    filas = int(input("Numero de filas: "))
    cols = int(input("Numero de columnas: "))

    matriz = [None]*filas

    for i in range(filas):        
        linea = input("")
        matriz[i] = linea.split(" ")

def mostrarDatos():
    for i in range(len(matriz)):
        print(" ".join(matriz[i]))

def ordenar():
    n = len(matriz) # filas
    m = len(matriz[0]) # columnas
    temporal = [None]*(n*m)

    for i in range(n):
        for j in range(m):
            temporal[m*i+j] = int(matriz[i][j])

    temporal.sort()

    for i in range(n):
        for j in range(m):
            matriz[i][j] = str(temporal[m*i+j])
    
def promedioFilas():
    n = len(matriz) # filas
    m = len(matriz[0]) # columnas
    promedio = [None]*n

    for i in range(n):
        suma = 0
        for j in range(m):
            suma += int(matriz[i][j])
        promedio[i] = suma/m

    for p in promedio:
        print(p, end="," )

def promedioColumnas():
    n = len(matriz) # filas
    m = len(matriz[0]) # columnas
    promedio = [None]*m

    for i in range(n):
        suma = 0
        for j in range(m):
            suma += int(matriz[j][i])
        promedio[i] = suma/m

    for p in promedio:
        print(p, end="," )

def main():
    opcion = 1

    while opcion != 9:
        print("Menu: ")
        print("1: leer Matriz")
        print("2: Mostrar Matriz")
        print("3: Ordenar Matriz")
        print("4: Promedio Filas")
        print("5: Promedio columnas")
        print("9: Salir")
        opcion = int(input("opcion: "))

        if opcion == 1:
            leerDatos()
        elif opcion == 2:
            mostrarDatos()
        elif opcion == 3:
            ordenar()
        elif opcion == 4:
            promedioFilas()
        elif opcion == 5:
            promedioColumnas()
            
main()
