'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2417592-2724
LABORATORIO 5
PROBLEMA 1
PROFESOR: JHON ALEXANDER VARGAS
int:
    -nombre del trabajador
    -horas que trabajo en cada una de las semanas 
salida:
       -el dinero total que gano cada empleado
       -el dinero gastado en nomina cada semana
'''

n=int(input('digite la cantidad de trabajadores: '))
m=int(input('digite la cantidad de semanas: '))

trabajadores=[]
horas_por_empleado = []
salarios = []


def leerDatos():
    for i in range (n):
        horas_semana = []
        nombre = input("Ingresa el nombre del trabajador: ")  
        for j in range (m):
            
            
            horast = float(input(f"Ingrese las horas trabajadas  de {nombre} en la semana {j+1} : "))
         
            horas_semana.append(horast)
        horas_por_empleado.append(horas_semana)
        trabajadores.append(nombre)
           

def calcularsalario():
    valor_hora = 10000
    for horas_semana in horas_por_empleado:
        salario_empleado = sum(horas_semana) * valor_hora
        salarios.append(salario_empleado)
        print(f"Salario de {trabajadores[len(salarios) - 1]}: ${salario_empleado}")


def gasto_semanal(horas_por_empleado):
    valor_hora = 10000
    num_semanas = len(horas_por_empleado[0])
    gasto_semanal = [sum(semana[i] for semana in horas_por_empleado) * valor_hora for i in range(num_semanas)]
    
    for i, gasto in enumerate(gasto_semanal):
        print(f"Gasto en nómina de la empresa en la semana {i + 1}: ${gasto}")
  

def main():
    opcion=1
    while opcion != 9:
        print("Menu: ")
        print("1: leer Datos")
        print("2: Mostrar salario de cada empleado")
        print("3: Mostrar gasto semanal")
       
        print("9: salir")
        opcion = int(input("opcion: "))

        if opcion == 1:
            leerDatos()
        elif opcion==2:
            calcularsalario()
        elif opcion==3:
            gasto_semanal(horas_por_empleado)
           
main()