import pygame
import random
# Inicialización de Pygame
pygame.init()

# Configuración de la ventana
pantalla = pygame.display.set_mode((1080, 720))
pygame.display.set_caption('Juego de Competencia')

#declaro un numero aleatorio para la posicion x e y del objetivo
objetivo_x = random.randint(0, 1080)
objetivo_y = random.randint(0, 720)

# Posición inicial del cuadrado blanco
cuadrado_blanco_x = 30
cuadrado_blanco_y = 300
puntos_blanco=0

# Posición inicial del cuadrado morado
cuadrado_morado_x = 970
cuadrado_morado_y = 300
puntos_morado=0

#velocidad de los cuadrados
velocidad=1

def verificar_punto(jugador_pos, item_pos):
    return jugador_pos.colliderect(item_pos)

# Bucle principal del juego
running = True
while running:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pantalla.fill(('black'))
    pygame.draw.rect(pantalla, 'white', [cuadrado_blanco_x, cuadrado_blanco_y, 80, 80])
    pygame.draw.rect(pantalla, 'purple', [cuadrado_morado_x, cuadrado_morado_y, 80, 80])

    #mapping de teclas

    tecla = pygame.key.get_pressed()
   
    #cuadrado blanco
    if tecla[pygame.K_w]:
        cuadrado_blanco_y -= velocidad
    if tecla[pygame.K_s]:
        cuadrado_blanco_y += velocidad
    if tecla[pygame.K_a]:
        cuadrado_blanco_x -=velocidad
    if tecla[pygame.K_d]:
        cuadrado_blanco_x += velocidad
   
    #cuadrado morado
    if tecla[pygame.K_UP]:
        cuadrado_morado_y -= velocidad
    if tecla[pygame.K_DOWN]:
        cuadrado_morado_y += velocidad
    if tecla[pygame.K_LEFT]:
        cuadrado_morado_x -= velocidad
    if tecla[pygame.K_RIGHT]:
        cuadrado_morado_x += velocidad
   
    #limitar el movimiento de los cuadrados al tamaño de la pantalla
    cuadrado_blanco_x = max(0, min(cuadrado_blanco_x, 1080 - 80))
    cuadrado_blanco_y = max(0, min(cuadrado_blanco_y, 720 - 80))
    cuadrado_morado_x = max(0, min(cuadrado_morado_x, 1080 - 80))
    cuadrado_morado_y = max(0, min(cuadrado_morado_y, 720 - 80))
    
    pygame.draw.rect(pantalla, 'red', [objetivo_x, objetivo_y, 10, 10]) #objetivo
    
    #verifica quien obtuvo el punto y aumenta la velocidad del juego
    if verificar_punto(pygame.Rect(cuadrado_blanco_x, cuadrado_blanco_y, 80, 80), pygame.Rect(objetivo_x, objetivo_y, 10, 10)):
        puntos_blanco += 1
        objetivo_x, objetivo_y = random.randint(0, 1080), random.randint(0, 720)
        velocidad+=1
    
    if verificar_punto(pygame.Rect(cuadrado_morado_x, cuadrado_morado_y, 80, 80), pygame.Rect(objetivo_x, objetivo_y, 10, 10)):
        puntos_morado += 1
        objetivo_x, objetivo_y = random.randint(0, 1080), random.randint(0, 720)
        velocidad+=1
    
    #scoreboard
    fuente = pygame.font.Font(None, 36)
    texto_blanco = fuente.render(f'Puntos jugador 1: {puntos_blanco}', True, 'white')
    texto_morado = fuente.render(f'Puntos jugador 2: {puntos_morado}', True, 'purple')
    pantalla.blit(texto_blanco, (10, 10))
    pantalla.blit(texto_morado, (10, 40))

  # Mostrar mensaje del ganador
    if puntos_blanco >= 5:
        ganador_texto = fuente.render("¡Blanco es el ganador!", True, 'white')
        pantalla.blit(ganador_texto, (10, 70))
        objetivo_x, objetivo_y = -100, -100
        ganador_autor = fuente.render("AUTOR: BRANDON LASPRILLA", True, 'white')
        pantalla.blit(ganador_autor, (350, 300))
       
    elif puntos_morado >= 5:
        ganador_texto = fuente.render("¡Morado es el ganador!", True, 'purple')
        pantalla.blit(ganador_texto, (10, 70))
        objetivo_x, objetivo_y = -100, -100
        ganador_autor = fuente.render("AUTOR: BRANDON LASPRILLA", True, 'white')
        pantalla.blit(ganador_autor, (350, 300))
          
    # Actualiza la pantalla
    pygame.display.update()

pygame.quit()