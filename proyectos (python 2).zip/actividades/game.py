import random
import pygame

# Inicialización de Pygame
pygame.init()

# Configuración de la ventana
ancho, alto = 1080, 720
pantalla = pygame.display.set_mode((ancho, alto),)
pygame.display.set_caption('Juego de atrapar el item')




# Variables del juego
velocidad = 1
incremento_velocidad = 0.015  # Incremento más pequeño de la velocidad
puntos_jugador1 = 0
puntos_jugador2 = 0
fuente = pygame.font.Font(None, 36)

# Posiciones iniciales de los jugadores
jugador1_pos = pygame.Rect(100, 300, 50, 50)
jugador2_pos = pygame.Rect(700, 300, 50, 50)

# Ítem
item_pos = pygame.Rect(random.randint(50, ancho-50), random.randint(50, alto-50), 20, 20)

# Función para dibujar los elementos en pantalla
def dibujar():
    pantalla.fill('black')
    pygame.draw.rect(pantalla, 'white', jugador1_pos)
    pygame.draw.rect(pantalla, 'purple', jugador2_pos)
    pygame.draw.rect(pantalla, 'red', item_pos)  # Dibuja el ítem
    texto = fuente.render(f'Jugador 1 (blanco) : {puntos_jugador1}  Jugador 2 (morado) : {puntos_jugador2}', True, 'white',)
    pantalla.blit(texto, (ancho // 2 - texto.get_width() // 2, 10))
    pygame.display.flip()  # Actualiza la pantalla

# Función para actualizar la posición de los jugadores
def actualizar_posicion(teclas, jugador_pos):
    if teclas[pygame.K_UP] and jugador2_pos.y > 0: jugador2_pos.y -= velocidad
    if teclas[pygame.K_DOWN] and jugador2_pos.y < alto - 50: jugador2_pos.y += velocidad
    if teclas[pygame.K_LEFT] and jugador2_pos.x > 0: jugador2_pos.x -= velocidad
    if teclas[pygame.K_RIGHT] and jugador2_pos.x < ancho - 50: jugador2_pos.x += velocidad
    if teclas[pygame.K_w] and jugador1_pos.y > 0: jugador1_pos.y -= velocidad
    if teclas[pygame.K_s] and jugador1_pos.y < alto - 50: jugador1_pos.y += velocidad
    if teclas[pygame.K_a] and jugador1_pos.x > 0: jugador1_pos.x -= velocidad
    if teclas[pygame.K_d] and jugador1_pos.x < ancho - 50: jugador1_pos.x += velocidad

# Función para verificar si un jugador ha alcanzado el ítem
def verificar_punto(jugador_pos, item_pos):
    return jugador_pos.colliderect(item_pos)

# Bucle principal del juego
en_juego = True
ganador = None
while en_juego:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            en_juego = False

    teclas = pygame.key.get_pressed()
    actualizar_posicion(teclas, jugador1_pos)
    actualizar_posicion(teclas, jugador2_pos)

    if verificar_punto(jugador1_pos, item_pos):
        puntos_jugador1 += 1
        velocidad += incremento_velocidad
        item_pos = pygame.Rect(random.randint(50, ancho-50), random.randint(50, alto-50), 20, 20)
    elif verificar_punto(jugador2_pos, item_pos):
        puntos_jugador2 += 1
        velocidad += incremento_velocidad
        item_pos = pygame.Rect(random.randint(50, ancho-50), random.randint(50, alto-50), 20, 20)

    if puntos_jugador1 == 5:
        ganador = '¡Jugador 1 gana!'
        en_juego = False
    elif puntos_jugador2 == 5:
        ganador = '¡Jugador 2 gana!'
        en_juego = False

    dibujar()

# Muestra el ganador y espera a que el usuario cierre la ventana
if ganador:
    print(ganador)
    texto_ganador = fuente.render(ganador, True, 'white')
    pantalla.blit(texto_ganador, (ancho // 2 - texto_ganador.get_width() // 2, alto // 2 - 50))
    texto_autor = fuente.render('Autor: Brandon Lasprilla', True, 'white')
    pantalla.blit(texto_autor, (ancho // 2 - texto_autor.get_width() // 2, alto // 2))
    pygame.display.flip()
    esperando_cierre = True
    while esperando_cierre:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                esperando_cierre = False

pygame.quit()
