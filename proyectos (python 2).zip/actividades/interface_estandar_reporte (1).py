'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2417592-2724
PROFESOR: JHON ALEXANDER VARGAS
int:
    -nombre del producto
    -cantidad del producto
    -precio del producto
salida:
       -leer los datos
       -ordenar los datos por nombre,cantidad o precio
       -subtotal
       -total (sumatoria de los subtotales)
       -mostrar el autor
'''

from tkinter import *
from tkinter import simpledialog 
from tkinter import messagebox   

nombres = []
cantidades = []
precios = []
total_general = 0

def salir():
        raiz.destroy()

def llenar():
        global total_general
        nombre = entrada_nombre.get()
        cantidad = entrada_cantidad.get()
        precio = entrada_precio.get()
    
        if nombre and cantidad and precio:
                nombres.append(nombre)
                cantidades.append(int(cantidad))
                precios.append(float(precio))
                subtotal = int(cantidad) * float(precio)
                total_general += subtotal
                mostrar()
                entrada_nombre.delete(0, END)
                entrada_cantidad.delete(0, END)
                entrada_precio.delete(0, END)


def mostrar():
        ctReporte.delete('1.0', END)
        
        reporte = "Nombre\t\tCantidad\t\tPrecio\t\tSubtotal\n"
        for i in range(len(nombres)):
                subtotal = cantidades[i]*precios[i]
                reporte += nombres[i]+"\t\t"+str(cantidades[i])+"\t\t"+str(precios[i])+"\t\t"+str(subtotal)+"\n"
        reporte += f"\nTotal General: {total_general}"
        ctReporte.insert(END, reporte,)

def ordernarNombre():
        for i in range(len(nombres)):
                for j in range(len(nombres)-i-1):
                        if nombres[j] > nombres[j+1]:
                                temp = nombres[j]
                                nombres[j] = nombres[j+1]
                                nombres[j+1] = temp
                                
                                temp = cantidades[j]
                                cantidades[j] = cantidades[j+1]
                                cantidades[j+1] = temp
                                
                                temp = precios[j]
                                precios[j] = precios[j+1]
                                precios[j+1] = temp

        mostrar()

def ordernarCantidad():
        for i in range(len(nombres)):
                for j in range(len(nombres)-i-1):
                        if cantidades[j] > cantidades[j+1]:
                                temp = nombres[j]
                                nombres[j] = nombres[j+1]
                                nombres[j+1] = temp
                                
                                temp = cantidades[j]
                                cantidades[j] = cantidades[j+1]
                                cantidades[j+1] = temp
                                
                                temp = precios[j]
                                precios[j] = precios[j+1]
                                precios[j+1] = temp

        mostrar()

def mostrar_autor():
    messagebox.showinfo(message="BRANDON LASPRILLA", title="Autor")

def ordernarPrecios():
        for i in range(len(nombres)):
                for j in range(len(nombres)-i-1):
                        if precios[j] > precios[j+1]:
                                temp = nombres[j]
                                nombres[j] = nombres[j+1]
                                nombres[j+1] = temp
                                
                                temp = cantidades[j]
                                cantidades[j] = cantidades[j+1]
                                cantidades[j+1] = temp
                                
                                temp = precios[j]
                                precios[j] = precios[j+1]
                                precios[j+1] = temp

        mostrar()

def principal():
        pass
        
#Interfaz Gráfica
raiz = Tk()
raiz.title("Programa")
raiz.resizable(0,0)
raiz.geometry("600x400")

#Contenedor 1
ventana1 = Frame(raiz)
ventana1.config(bd=5,relief="sunken",)
ventana1.pack(padx =10, pady=10)


bCalcularPago = Button(ventana1, text="adiccionar", command=llenar)
bCalcularPago.grid(row=0, column=0,padx=10, pady=10)

bSalir = Button(ventana1, text="Salir", width=10, command=salir)
bSalir.grid(row=0, column=1)

btnOrdernarNombre = Button(ventana1, text="Ordenar por Nombre", command=ordernarNombre)
btnOrdernarNombre.grid(row=1, column=0,padx=10, pady=10)

btnOrdenarCantidad = Button(ventana1, text="Ordenar Por Cantidad", command=ordernarCantidad)
btnOrdenarCantidad.grid(row=1, column=1,padx=10, pady=10)

btnOrdenarPrecio = Button(ventana1, text="Ordenar por Precio", command=ordernarPrecios)
btnOrdenarPrecio.grid(row=1, column=2,padx=10, pady=10)

botonAceptar = Button(ventana1, text="Mostrar Autor",bg="yellow", command=mostrar_autor )
botonAceptar.grid(row=1,column=3,padx=10, pady=10)

# Contenedor para entradas
frame_entradas = Frame(raiz)
frame_entradas.pack(padx=10, pady=10)

Label(frame_entradas, text="Nombre:").grid(row=0, column=0)
entrada_nombre = Entry(frame_entradas)
entrada_nombre.grid(row=0, column=1)

Label(frame_entradas, text="Cantidad:").grid(row=1, column=0)
entrada_cantidad = Entry(frame_entradas)
entrada_cantidad.grid(row=1, column=1)

Label(frame_entradas, text="Precio:").grid(row=2, column=0)
entrada_precio = Entry(frame_entradas)
entrada_precio.grid(row=2, column=1)

# Area de texto para mostrar el reporte.
ctReporte = Text(raiz, height=13, width=60,)
ctReporte.pack()

raiz.mainloop()