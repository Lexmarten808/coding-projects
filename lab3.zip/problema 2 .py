'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2417592-2724
LABORATORIO 3
PROBLEMA 2
PROFESOR: JHON ALEXANDER VARGAS
int:
    -numero de empleados
    -nombre del empleado(#)
    -# documento del empleado(#)
    -salario del empleado(#)
salida:
       -nombre completo del empleado(#)
       -# documento del empleado(#)
       -salario
       -bonificacion de servicios
       -subsidio de transporte
       -subsidio de transporte
       -descuentos(salud,pension,retefuente)
       -totales(pago,descuentos,neto a pagar)
'''
    #defino la funcion pagos usando el salario
def pagos(salario):
    #calculo el descuento en base al salario
    pagosalud=salario*0.04
    pagopension=salario*0.04
    retefuente=salario*0.05
   
    return pagosalud,pagopension,retefuente
def main():
    #2 pido el numero de empleados
    n=int(input('digite el numero de empleados: '))
    #3 defino el ciclo usando for y (n) numero de empleados
    
    for x in range (1,n +1):
        
        nombrecompleto=input(f'introduzca el nombre completo del empleado ({x}): ')
        didentidad=input('digite el numero del documento de identidad: ')
        salario=int(input('digite su salario: '))
        stransporte = salario * 0.2
        bonificacion = salario * 0.1
        pagosalud,pagopension,retefuente=pagos(salario)
        totalpagos=salario+stransporte+bonificacion
        totaldescuentos=pagosalud+pagopension+retefuente
        netoapagar=totalpagos-totaldescuentos
        print('========== DATOS DEL EMPLEADO ==========')
        print(f' nombre completo: {nombrecompleto}')
        print(f'numero del documento de indentidad: {didentidad}')
        print('================ PAGOS =================')
        print(f'salario: {salario}')
        print(f'bonificacion de servicios: {bonificacion}')
        print(f'subsidio de transporte: {stransporte}')
        print('=============== DESCUENTOS ==============')
        print(f'salud: {pagosalud}')
        print(f'pension: {pagopension}')
        print(f'retefuente: {retefuente}')
        print('================ TOTALES ==================')
        print(f'total pagos: {totalpagos}')
        print(f'total descuentos: {totaldescuentos}')
        print(f'neto a pagar: {netoapagar}')
main()
        
