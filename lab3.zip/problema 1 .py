'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2417592-2724
LABORATORIO 3
PROBLEMA 1
PROFESOR: JHON ALEXANDER VARGAS
int:
    -datos del jefe del hogar y numero de familiares a registrar
    -datos de los familiares 
salida:
       -datos del jefe del hogar
       -datos de cada uno de los familiares
'''
    #1 defino la funcion jefe hogar que reune los datos de este mismo
def jefehogar():
    nombre=input('introduzca el nombre del jefe del hogar: ')
    apellido=input('introduzca el apellido del jefe del hogar: ')
    tipodocumento=input('introduzca el tipo de documento de identidad: ')
    numerodocumento=input('introduzca el numero del documento de identidad: ')
    fechanacimiento=input('introduzca la fecha de nacimiento: ')
    dnacimiento=input('introduzca el departamento de nacimiento: ')
    cnacimiento=input('introduzca la ciudad de nacimiento:')
    dresidencia=input('introduzca la direccion de la residencia: ')
    # 2 le pido el numero de familiares a registrar para usarlo en el for
    cfamiliares=int(input('introduzca la cantidad de familiares a registrar: ')) 
    return nombre, apellido, tipodocumento, numerodocumento, fechanacimiento, dnacimiento, cnacimiento, dresidencia, cfamiliares
    #3 defino la funcion principal
def main():
    #4 llamo a la funcion jefe de hogar para imprimir sus datos y tener la cantidad de familiares para usarse en el for
    nombre, apellido, tipodocumento, numerodocumento, fechanacimiento, dnacimiento, cnacimiento, dresidencia, cfamiliares = jefehogar()
    print('=========================================')
    print("Datos del jefe de hogar:")
    print(f"Nombre: {nombre} {apellido}")
    print(f"Tipo de documento de identidad: {tipodocumento}")
    print(f"Número de documento de identidad: {numerodocumento}")
    print(f"Fecha de nacimiento: {fechanacimiento}")
    print(f"Departamento de nacimiento: {dnacimiento}")
    print(f"Ciudad de nacimiento: {cnacimiento}")
    print(f"Dirección de residencia: {dresidencia}")
    print('=========================================')
    #5 creo el ciclo utilizando el for para la cantidad de familiares dada previamente
    for x in range(1,cfamiliares+ 1 ):
         #6 pido los datos para cada uno de los familiares 
         nombre=input(f'introduzca el nombre del integrante {x}: ')
         apellido=input('introduzca el apellido del jefe del hogar: ')
         tipodocumento=input('introduzca el tipo de documento de identidad: ')
         numerodocumento=input('introduzca el numero del documento de identidad: ')
         fechanacimiento=input('introduzca la fecha de nacimiento: ')
         parentesco=input('introduzca el parentesco: ')
         #7 muestro los datos
         print('=========================================')
         print(f"Miembro {x}: {nombre} {apellido}")
         print(f'tipo de documento: {tipodocumento}')
         print(f'numero de documento: {numerodocumento}')
         print(f'fecha de nacimiento: {fechanacimiento}')
         print(f'parentesco: {parentesco}')
         print('=========================================')
main()