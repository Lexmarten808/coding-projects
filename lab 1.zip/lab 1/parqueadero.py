'''
El centro comercial los laureles a contratado sus servicios para la realización de un aplicativo que le permita cobrar a sus clientes el servicio de parqueadero.
El horario de atención del centro comercial es de lunes a domingo de 8:00 am a 8:00 pm. Para calcular el valor que un cliente debe pagar se debe tener en cuenta los siguientes criterios:
Automóviles : los primeros 30 minutos son gratis. Hasta 3 horas paga $3.500. Minuto adicional $25
Motos: $2.200 hora.
Se requiere que la factura que se le entregue al cliente tenga los siguientes datos:
Fecha, hora de llegada, hora de salida, tiempo de permanencia (horas y minutos), valor a pagar.
'''
#1 se pide la hora de entrada y de salida
#2 preguntar que vehiculo es si es moto o carro 
#3 si es carro los 30 primeros min son gratis hasta 3 horas paga 3.500 y el munito adicional 25
#4 si es moto 2.200 la hora 
def valor_pagar(h,m,vehiculo):
    if vehiculo == 'moto':
        
        valor=2200
       
        
    else: 
        valor=3500
    permanencia_minutos=h*60+m
    if permanencia_minutos<=30:
        costo_total=0
    elif permanencia_minutos>=180:
        costo_total=valor
    else:
        m_adiccionales= m-180
        costo_total=m_adiccionales//60*25
    return costo_total

        
       
        
    
        
        
def main():
    
    
    h=int(input('introduzca las horas que el vehiculo estuvo parqueado: '))
    m=int(input('introduzca los minutos que el vehiculo estuvo parqueado: '))
    vehiculo=input('introduzca el tipo de vehiculo (si es moto o carro): ')
    fecha=input('introduzca la fecha: ')
    hora_llegada=(input('introduzca la hora de llegada: '))
    hora_salida=(input('introduzca la hora de salida: '))
    costo_total=valor_pagar(h,m,vehiculo)
    
    

    print(f'fecha: {fecha}')
    print(f'hora de legada: {hora_llegada} ')
    print(f'hora salida: {hora_salida}')
    print(f'tiempo de permanencia: {h} horas y {m} minutos')
    print(f'valor a pagar: {costo_total}')
if __name__ == '__main__':
    main()


    




    
    
