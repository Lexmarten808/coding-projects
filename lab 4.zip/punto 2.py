'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2417592-2724
LABORATORIO 4
PROBLEMA 1
PROFESOR: JHON ALEXANDER VARGAS
int:
    -numero de filas
    -numero de columnas
    -1 o 0 para indicar si la bodega esta ocupada o no
salida:
    -espacios que la bodega tiene desocupados
    -la fila con mas espacios desocupados y cuantos espacios vacios tiene
'''

def crear_bodega(filas, columnas):
    return [[0 for x in range(columnas)] for x in range(filas)]

def registrar_espacios(bodega):
    for i in range(len(bodega)):
        for j in range(len(bodega[i])):
            bodega[i][j] = int(input(f"Ingrese 1 si el espacio ({i+1}, {j+1}) está ocupado, de lo contrario 0: "))

def imprimir_bodega(bodega):
    for fila in bodega:
        print(' '.join(str(espacio) for espacio in fila))

def calcular_desocupados(bodega):
    suma=sum(fila.count(0) for fila in bodega)
    return suma

def fila_con_mas_desocupados(bodega):
    
    fila_max = 0
    max_desocupados = 0
    
    # Recorrer la bodega para encontrar la fila con más desocupados
    for i in range(len(bodega)):
        # Contar los desocupados en la fila actual
        desocupados_actual = bodega[i].count(0)
        
        # Utilizar el método de burbuja para encontrar el máximo
        if desocupados_actual > max_desocupados:
            max_desocupados = desocupados_actual
            fila_max = i
    
    return fila_max, max_desocupados

def main():
    filas = int(input("Ingrese el número de filas de la bodega: "))
    columnas = int(input("Ingrese el número de columnas de la bodega: "))

    bodega = crear_bodega(filas, columnas)
    registrar_espacios(bodega)
    
    fila_max, max_desocupados = fila_con_mas_desocupados(bodega)

    while True:
        print("Menú:")
        
        print("1. Imprimir la bodega")
        print("2. Mostrar la fila con más espacios desocupados")
        print("3. cantidad de espacios")
        print("4. Salir")
        opcion = input("Seleccione una opción: ")

        
        if opcion == '1':
            imprimir_bodega(bodega)
        elif opcion == '2':
            fila_max, max_desocupados = fila_con_mas_desocupados(bodega)
            print('=============================================================================================================')
            print(f"La fila con más espacios desocupados es la fila {fila_max+1} con {max_desocupados} espacios desocupados")
            print('=============================================================================================================')
        elif opcion=='3':
            espacios=calcular_desocupados(bodega)
            print('=========================================')
            print(f'la cantidad de espacios vacios son: {espacios}')
            print('=========================================')
        elif opcion == '4':
            print("Saliendo del programa...")
            break
        else:
            print("Opción no válida. Por favor, intente de nuevo.")

main()