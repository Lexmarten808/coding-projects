'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2417592-2724
LABORATORIO 4
PROBLEMA 1
PROFESOR: JHON ALEXANDER VARGAS
int:
    -s/n para seguir
    -nombres
    -nota final

salida:
       -promedio
       -reporte nota y si aprobo
       -nombre de os que ganaron en 5
       -nota que mas se repite
       -porcentaje de la nota mas repetida

listas multiples
'''
cantestudiantes=int(input('digite la cantidad de estudiantes: '))
estudiantes=[]
nota=[]
def leerDatos():
    for x in range (cantestudiantes):
        nombre = input("Ingresa el nombre del estudiante (o 'fin' para terminar): ")
    
        
        notas = float(input(f"Ingrese la nota de {nombre} (de 0.0 a 5.0): "))
        estudiantes.append(nombre)
        nota.append(notas)

def mostrarDatos(nota):
    print('==============================')
    for i in range(len(nota)):
        print(estudiantes[i] + " : " + str(nota[i]))
    print('==============================')
      
def calcular_promedio():
    return sum(nota) / len(nota)

def reporte_aprobados():
    return [(estudiantes[i], nota[i]) for i in range(len(estudiantes)) if nota[i] >= 3.0]

def EDestacados():
    estudiantes5 = [estudiantes[i] for i in range(len(estudiantes)) if nota[i] == 5.0]
    
        
    return estudiantes5

def calcularModa(nota):
    contadores = [0]*len(nota)
    for x in range(len(nota)):
        for i in range(len(nota)):
            if nota[x] == nota[i]:
                contadores[x] += 1
    mayor = contadores[0]
    pos_mayor = 0
    for i in range(1, len(contadores)):
        if contadores[i] > mayor:
            mayor = contadores[i]
            pos_mayor = i
    return nota[pos_mayor],mayor

def main():
    opcion=1
    while opcion != 9:
        print("Menu: ")
        print("1: leer Datos")
        print("2: Mostrar Datos")
        print("3: Mostrar Promedio")
        print("4: Mostrar aprobados")
        print("5: Mostrar estudiantes destacados")
        print("6: Mostrar Moda")
        print("7: mostrar promedio de la moda")
        print("9: salir")
        opcion = int(input("opcion: "))

        if opcion == 1:
            leerDatos()
        elif opcion==2:
            mostrarDatos(nota) 
           
        
        elif opcion==3:
            m=calcular_promedio()
            print('==============================')
            print(f'promedio de notas: {m}')
            print('==============================')
         
        elif opcion==4:
            m=reporte_aprobados()
            print('==============================')
            print(f'aprobados: {m}')
            print('==============================')
        elif opcion==5:
            m=EDestacados()
            print('=========================================')
            print(f'Estudiantes con 5.0: {m}')
            print('=========================================')
        
        elif opcion==6:
            m,n=calcularModa(nota)
            print('===============================================================') 
            print(f'Moda: ({m}) la cantidad de estudiantes con esta nota son : {n}')
            print('===============================================================')
        
        elif opcion==7:
            moda, total_moda = calcularModa(nota)
            porcentaje = (total_moda / cantestudiantes) * 100
            print('============================================================')
            print(f'Porcentaje de estudiantes con la nota {moda}: {porcentaje} %')
            print('============================================================')

main()

