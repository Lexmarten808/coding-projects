'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2419572-2724
SOLUCION TALLER LAB 2
ENTRADAS:
valor de x
SALIDAS:
solucion ecuacion con el valor de x
'''
def funcion(x):
    if x <=0 :
        fdex=8*x**2-6
    else:
        fdex=3*x+5
    return fdex
def main():
    x=int(input('introduce el valor de x: '))
    f_x=funcion(x)
    print(f'f({x})= {f_x}')
main()
        
    