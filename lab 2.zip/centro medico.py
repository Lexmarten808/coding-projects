'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2419572-2724
SOLUCION TALLER LAB 2
ENTRADAS:
nombre
peso
altura
SALIDA:
nombre
imc
categoria

'''
def imc(p,a):
    imc=p/a**2
    if imc<18.5:
        c_peso=('infrapeso')
    elif imc<25.0:
        c_peso=('normal')
    else :
        c_peso=('sobre peso')

    return imc,c_peso

    
    
def main():
    p=float(input('introduzca el peso (kg): '))
    a=float(input('introduzca la altura (mts): '))
    paciente=input('introduzca el nombre completo de el paciente: ')
    imcp,c_peso= imc(p,a)
    
    print(f'paciente: {paciente}')
    print(f'imc: {imcp}')
    print(f'categoria: {c_peso}')
    
    
main()

    