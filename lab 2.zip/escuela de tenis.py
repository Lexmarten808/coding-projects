'''
BRANDON LASPRILLA ARISTIZABAL CODIGO:2419572-2724
SOLUCION TALLER LAB 2
ENTRADAS:
edad
nombre
SALIDA:
nombre
categoria
mensualidad
'''
def valor_pagar(e):
    if e < 12:
        c = 'infantil'
        m = 43000
    elif e < 18:
        c = 'juvenil'
        m = 36000
    else:
        c = 'mayores'
        m = 32000
    return c, m
def main():
    
    e=int(input('introduzca la edad: '))
    
    c,mensualidad=valor_pagar(e)
    
    n=input('introduzca el nombre: ')
    print (f'nombre: {n}')
    print (f'categoria: {c}')
    print (f'mensualidad: {mensualidad}')

main()
